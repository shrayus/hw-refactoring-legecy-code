Recaptcha.configure do |config|
  config.public_key  = 'YourAPIkeysHere_yyyyyyyyyyyyyyyyy'
  config.private_key = 'YourAPIkeysHere_xxxxxxxxxxxxxxxxx'
end
