Date.weekdays = $w('Ma Ti On To Fr Lø Sø');
Date.months = $w('Januar Februar Marts April Maj Juni Juli August September Oktober November December');

Date.first_day_of_week = 1;

_translations = {
  "OK": "Vælg",
  "Now": "Nu",
  "Today": "I dag",
  "Clear": "Slet"
}
