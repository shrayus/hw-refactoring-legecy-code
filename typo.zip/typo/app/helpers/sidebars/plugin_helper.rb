module Sidebars::PluginHelper
end
