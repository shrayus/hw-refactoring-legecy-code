class TagsController < GroupingController
  # index, #show are inherited
end
